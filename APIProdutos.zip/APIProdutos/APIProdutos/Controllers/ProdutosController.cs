﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using APIProdutos.Business;
using APIProdutos.Models;

namespace APIProdutos.Controllers
{
    [Route("api/[controller]")]
    public class ProdutosController : Controller
    {
        private ProdutoService _service;

        public ProdutosController(ProdutoService service)
        {
            _service = service;
        }

        // MÉTODO GET TRAZENDO TUDO

        [HttpGet("{codigoBarras}")]
        public IActionResult Get(string codigoBarras)
        {
            var produto = _service.Obter(codigoBarras);
            if (produto != null)
                return new ObjectResult(produto);
            else
                return NotFound();
        }

        // IMPLEMENTAR POST INCLUSAO

        // IMPLEMENTAR PUT ALTERACAO

        // IMPLEMENTAR DELETE EXCLUSAO
    }
}