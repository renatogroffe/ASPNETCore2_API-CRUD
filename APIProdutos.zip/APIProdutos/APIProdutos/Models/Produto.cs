﻿namespace APIProdutos.Models
{
    public class Produto
    {
    }
}